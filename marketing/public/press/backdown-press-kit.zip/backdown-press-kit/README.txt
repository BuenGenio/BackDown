BackDown press kit
==================

https://backdown.io/press/

In 25 words
-----------

BackDown is local backup software that tells you what's on your drives: what's duplicated, what each folder is, and which drives are safe to wipe.

In 50 words
-----------

BackDown is backup software for people with a drawer of old drives. It indexes every drive you own, finds what's duplicated across them, recognises what each folder is and where it came from, and proves with SHA-256 hashes which drives are safe to wipe. It runs locally, without an account.

In 100 words
------------

BackDown is backup software for people with a drawer of old drives. It indexes every drive and folder you point it at, hashes only the files that could be duplicates, and shows what's duplicated across all of them. It recognises what things are, such as mail stores, phone backups and Time Machine sets, and where they came from. Before you wipe a drive, it proves with SHA-256 hashes that every file has an identical copy elsewhere. BackDown runs on your own computer, with no account and no telemetry. Its free beta, desktop app included, runs on Linux, macOS and Windows.

Facts
-----

Product: BackDown
What it is: Backup software that tells you what's on your drives: what's duplicated, what each folder is, where it came from, and which drives are safe to wipe, with a SHA-256 hash behind every claim.
Website: backdown.io
Started: 2026, as the consolidation of 27 million files and 15 TB on a desk full of old drives. The first public preview came out on 27 September 2026.
Status: Early access. Latest release: v1.0.0-beta.9 (https://github.com/BuenGenio/backdown-releases/releases), 9 Nov 2026, a public beta of the desktop app and the command line.
Platforms: Desktop app and command line: Linux (.deb · AppImage · CLI); macOS (.dmg · CLI · universal); Windows (.msi · setup · CLI). Installers aren't signed or notarised yet.
Pricing: The beta is free, with every feature unlocked. Planned: the core free forever; Pro $8 a month per machine, or $80 a year. Pricing (https://backdown.io/pricing/).
Privacy: Runs on your own computer. No account, no telemetry: the local edition makes no network requests unless you ask it to (checking for updates, or reaching your own machines).
Website languages: English, Spanish, Brazilian Portuguese, German, Polish, Czech, Slovak and Ukrainian.

Logos (logos/)
--------------

SVG and PNG, transparent. The "-dark" files are for dark backgrounds. The mark is orange #d8432b
(#f0603f on dark), the lettering charcoal #17161b (ivory #f5f3ec on dark). Keep clear space of
at least half the mark's height around it; please don't recolour, stretch or add effects.
The wordmark is set in Bricolage Grotesque (ExtraBold).

Screenshots (screenshots/)
--------------------------

Real BackDown screens, shown with demo data, 2400 px wide, in light and dark:

- overview: Everything you have, at a glance
- verdicts: A verdict for every drive
- tree: See where the bytes are
- duplicates: Duplicates across every drive
- verification: Hash-verified, folder by folder
- dashboard: Watch it work
